console.log("test2");



var a = 2;
var b = 4;

console.log(a + b);




/*
var button = document.getElementById("submitknop");

button.addEventListener('click', checkUsername);

function checkUsername() {


	var test1 = document.getElementById('feedback')
	var test2 = document.getElementById('name');
	if (test2.value.length < 5) {
		test1.textContent = 'Username must be 5 characters or more';
	} else {
		test1.textContent = '';
	}
}
*/

function veranderKleur() {
		var myElement = document.getElementById('bdbackground');
		if (myElement.className == 'grijs') {
			myElement.className = 'groen';
		} else if (myElement.className == 'groen') {
			myElement.className = 'grijs';
		}
	}
